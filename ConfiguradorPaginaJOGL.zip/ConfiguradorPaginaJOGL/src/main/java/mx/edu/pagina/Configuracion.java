package mx.edu.pagina;

/** Estado inmutable de una hoja A4. Todas las medidas están en milímetros. */
public record Configuracion(boolean horizontal, int superior, int inferior,
                            int izquierdo, int derecho) {
    public Configuracion {
        int ancho = horizontal ? 297 : 210;
        int alto = horizontal ? 210 : 297;
        if (superior < 0 || inferior < 0 || izquierdo < 0 || derecho < 0)
            throw new IllegalArgumentException("Los márgenes no pueden ser negativos.");
        if ((long) izquierdo + derecho >= ancho || (long) superior + inferior >= alto)
            throw new IllegalArgumentException("Los márgenes deben dejar espacio útil dentro de la hoja.");
    }
    public static Configuracion inicial() { return new Configuracion(false, 0, 0, 0, 0); }
    public int ancho() { return horizontal ? 297 : 210; }
    public int alto() { return horizontal ? 210 : 297; }
    public int anchoUtil() { return ancho() - izquierdo - derecho; }
    public int altoUtil() { return alto() - superior - inferior; }
}
