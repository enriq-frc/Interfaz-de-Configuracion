package mx.edu.pagina;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLJPanel;
import java.awt.Dimension;

/** La hoja, las guías y el contenido se dibujan realmente con OpenGL / JOGL. */
public final class VistaPagina extends GLJPanel implements GLEventListener {
    private static final long serialVersionUID = 1L;
    private volatile Configuracion estado = Configuracion.inicial();
    private volatile boolean guias = true;
    public VistaPagina() {
        super(new GLCapabilities(GLProfile.get(GLProfile.GL2)));
        setPreferredSize(new Dimension(600, 570));
        addGLEventListener(this);
    }
    public void actualizar(Configuracion estado, boolean guias) {
        this.estado = estado;
        this.guias = guias;
        repaint();
    }
    @Override public void init(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();
        gl.glDisable(GL.GL_DEPTH_TEST);
    }
    @Override public void dispose(GLAutoDrawable drawable) { }
    @Override public void reshape(GLAutoDrawable d, int x, int y, int w, int h) { }
    @Override public void display(GLAutoDrawable d) {
        GL2 gl = d.getGL().getGL2();
        int w = Math.max(1, d.getSurfaceWidth()), h = Math.max(1, d.getSurfaceHeight());
        gl.glViewport(0, 0, w, h);
        gl.glClearColor(.925f, .941f, .961f, 1f);
        gl.glClear(GL.GL_COLOR_BUFFER_BIT);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        // Origen superior izquierdo para relacionar fácilmente los márgenes con la UI.
        gl.glOrtho(0, w, h, 0, -1, 1);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();
        Configuracion c = estado;
        double escala = Math.min(w * .80 / c.ancho(), h * .84 / c.alto());
        double pw = c.ancho() * escala, ph = c.alto() * escala;
        double x = (w - pw) / 2, y = (h - ph) / 2;
        rect(gl, x + 7, y + 9, pw, ph, .82f, .85f, .90f);
        rect(gl, x, y, pw, ph, 1f, 1f, 1f);
        double ix = x + c.izquierdo() * escala, iy = y + c.superior() * escala;
        double iw = c.anchoUtil() * escala, ih = c.altoUtil() * escala;
        // Las franjas coloreadas representan el espacio reservado a los márgenes.
        rect(gl, x, y, pw, c.superior() * escala, .88f, .94f, 1f);
        rect(gl, x, y + ph - c.inferior() * escala, pw, c.inferior() * escala, .88f, .94f, 1f);
        rect(gl, x, iy, c.izquierdo() * escala, ih, .88f, .94f, 1f);
        rect(gl, x + pw - c.derecho() * escala, iy, c.derecho() * escala, ih, .88f, .94f, 1f);
        // Texto simulado: líneas decorativas confinadas al área útil.
        if (iw > 30 && ih > 30) {
            double pad = Math.min(iw, ih) * .08;
            double lineH = Math.min(4 * escala, ih / 40);
            for (int i = 0; i < 12; i++) {
                double ly = iy + pad + i * lineH * 2.3;
                if (ly + lineH >= iy + ih - pad) break;
                double lw = (iw - 2 * pad) * (i == 0 ? .62 : i % 4 == 3 ? .72 : 1);
                rect(gl, ix + pad, ly, lw, lineH, i == 0 ? .21f : .82f,
                     i == 0 ? .39f : .86f, i == 0 ? .65f : .91f);
            }
        }
        gl.glLineWidth(1f);
        borde(gl, x, y, pw, ph, .56f, .63f, .73f);
        if (guias) {
            gl.glEnable(GL2.GL_LINE_STIPPLE);
            gl.glLineStipple(1, (short) 0x0F0F);
            borde(gl, ix, iy, iw, ih, .12f, .40f, .90f);
            gl.glDisable(GL2.GL_LINE_STIPPLE);
        }
        gl.glFlush();
    }
    private static void rect(GL2 gl, double x, double y, double w, double h, float r, float g, float b) {
        gl.glColor3f(r, g, b);
        gl.glBegin(GL2.GL_QUADS);
        vertices(gl, x, y, w, h);
        gl.glEnd();
    }
    private static void borde(GL2 gl, double x, double y, double w, double h, float r, float g, float b) {
        gl.glColor3f(r, g, b);
        gl.glBegin(GL2.GL_LINE_LOOP);
        vertices(gl, x, y, w, h);
        gl.glEnd();
    }
    private static void vertices(GL2 gl, double x, double y, double w, double h) {
        gl.glVertex2d(x, y); gl.glVertex2d(x + w, y);
        gl.glVertex2d(x + w, y + h); gl.glVertex2d(x, y + h);
    }
}
