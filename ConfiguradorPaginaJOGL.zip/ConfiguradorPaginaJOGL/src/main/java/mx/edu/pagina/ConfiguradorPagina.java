package mx.edu.pagina;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Ventana Swing; JOGL se encarga de la vista previa. Ejecutar esta clase. */
public final class ConfiguradorPagina extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final Color AZUL = new Color(32, 94, 215);
    private final JSpinner superior = margen(), inferior = margen(), izquierdo = margen(), derecho = margen();
    private final JComboBox<String> orientacion = new JComboBox<>(new String[]{"Vertical", "Horizontal"});
    private final JCheckBox guias = new JCheckBox("Mostrar guías de márgenes", true);
    private final JLabel dimensiones = new JLabel(), area = new JLabel(), estado = new JLabel(" ");
    private final VistaPagina vista = new VistaPagina();
    private Configuracion configuracion = Configuracion.inicial();
    private boolean sincronizando;

    public ConfiguradorPagina() {
        super("Configurador de página | Java + JOGL");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(880, 650));
        JPanel raiz = new JPanel(new BorderLayout(22, 18));
        raiz.setBackground(new Color(245, 247, 251));
        raiz.setBorder(new EmptyBorder(22, 24, 18, 24));
        setContentPane(raiz);
        JPanel titulo = new JPanel(new GridLayout(2, 1, 0, 5));
        titulo.setOpaque(false);
        JLabel encabezado = new JLabel("Configuración de página");
        encabezado.setFont(new Font("SansSerif", Font.BOLD, 27));
        titulo.add(encabezado);
        titulo.add(new JLabel("Ajusta tu hoja y observa los cambios al instante."));
        raiz.add(titulo, BorderLayout.NORTH);

        JPanel controles = new JPanel(new GridBagLayout());
        controles.setBackground(Color.WHITE);
        controles.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.gridy = 0; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        g.insets = new Insets(0, 0, 10, 0);
        agregar(controles, g, negrita("HOJA A4"));
        agregar(controles, g, new JLabel("Orientación de página"));
        agregar(controles, g, orientacion);
        agregar(controles, g, dimensiones);
        agregar(controles, g, new JSeparator());
        agregar(controles, g, negrita("MÁRGENES · milímetros"));
        agregar(controles, g, campo("Superior", superior));
        agregar(controles, g, campo("Inferior", inferior));
        agregar(controles, g, campo("Izquierdo", izquierdo));
        agregar(controles, g, campo("Derecho", derecho));
        guias.setOpaque(false);
        agregar(controles, g, guias);
        agregar(controles, g, area);
        JButton reset = new JButton("Restablecer / Reset");
        reset.setBackground(AZUL); reset.setForeground(Color.WHITE);
        reset.setFocusPainted(false);
        reset.setToolTipText("Márgenes en cero y orientación vertical");
        agregar(controles, g, reset);
        agregar(controles, g, new JLabel("Reset: 0 mm + hoja vertical"));
        g.weighty = 1;
        agregar(controles, g, new JLabel(" "));
        raiz.add(controles, BorderLayout.WEST);

        JPanel previa = new JPanel(new BorderLayout(0, 10));
        previa.setOpaque(false);
        previa.add(negrita("VISTA PREVIA · JOGL / OpenGL"), BorderLayout.NORTH);
        previa.add(vista, BorderLayout.CENTER);
        previa.add(new JLabel("Azul claro: márgenes   ·   Línea azul: área útil"), BorderLayout.SOUTH);
        raiz.add(previa, BorderLayout.CENTER);
        estado.setPreferredSize(new Dimension(100, 28));
        raiz.add(estado, BorderLayout.SOUTH);

        for (JSpinner s : new JSpinner[]{superior, inferior, izquierdo, derecho})
            s.addChangeListener(e -> aplicar());
        orientacion.addActionListener(e -> aplicar());
        guias.addActionListener(e -> vista.actualizar(configuracion, guias.isSelected()));
        reset.addActionListener(e -> {
            configuracion = Configuracion.inicial();
            sincronizar();
            refrescar("Restablecido: todos los márgenes en 0 mm y orientación vertical.", false);
        });
        refrescar("Listo. Modifica los márgenes o la orientación.", false);
        pack();
        setLocationRelativeTo(null);
    }
    private void aplicar() {
        if (sincronizando) return;
        try {
            configuracion = new Configuracion(orientacion.getSelectedIndex() == 1,
                valor(superior), valor(inferior), valor(izquierdo), valor(derecho));
            refrescar("Configuración actualizada.", false);
        } catch (IllegalArgumentException ex) {
            sincronizar(); // Recupera la última configuración válida, incluso la orientación.
            refrescar(ex.getMessage() + " Se conservó el ajuste anterior.", true);
        }
    }
    private void sincronizar() {
        sincronizando = true;
        try {
            superior.setValue(configuracion.superior()); inferior.setValue(configuracion.inferior());
            izquierdo.setValue(configuracion.izquierdo()); derecho.setValue(configuracion.derecho());
            orientacion.setSelectedIndex(configuracion.horizontal() ? 1 : 0);
        } finally { sincronizando = false; }
    }
    private void refrescar(String texto, boolean error) {
        dimensiones.setText(configuracion.ancho() + " × " + configuracion.alto() + " mm");
        area.setText("Área útil: " + configuracion.anchoUtil() + " × " + configuracion.altoUtil() + " mm");
        estado.setForeground(error ? new Color(174, 44, 44) : new Color(48, 87, 69));
        estado.setText(texto);
        estado.setToolTipText(texto);
        vista.actualizar(configuracion, guias.isSelected());
    }
    private static JSpinner margen() {
        JSpinner s = new JSpinner(new SpinnerNumberModel(0, 0, 296, 1));
        JSpinner.NumberEditor editor = new JSpinner.NumberEditor(s, "0");
        s.setEditor(editor);
        // Se confirma al pulsar Enter o al salir del campo; un texto inválido revierte.
        editor.getTextField().setFocusLostBehavior(JFormattedTextField.COMMIT_OR_REVERT);
        s.setPreferredSize(new Dimension(100, 34));
        return s;
    }
    private static int valor(JSpinner s) { return ((Number) s.getValue()).intValue(); }
    private static JLabel negrita(String s) {
        JLabel l = new JLabel(s); l.setFont(new Font("SansSerif", Font.BOLD, 13)); return l;
    }
    private static JPanel campo(String nombre, JSpinner spinner) {
        JPanel p = new JPanel(new BorderLayout(16, 0)); p.setOpaque(false);
        JLabel etiqueta = new JLabel(nombre); etiqueta.setLabelFor(spinner);
        p.add(etiqueta, BorderLayout.CENTER); p.add(spinner, BorderLayout.EAST); return p;
    }
    private static void agregar(JPanel p, GridBagConstraints g, JComponent c) {
        p.add(c, g); g.gridy++;
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
                UIManager.put("Label.font", new Font("SansSerif", Font.PLAIN, 13));
                new ConfiguradorPagina().setVisible(true);
            } catch (Throwable ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null,
                    "No se pudo iniciar la vista JOGL.\nComprueba las dependencias Maven y el controlador gráfico.\n"
                    + ex.getClass().getSimpleName() + ": " + ex.getMessage(),
                    "Error al iniciar", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
